package com.example.nagoyameshi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.CategoryRestaurant;
import com.example.nagoyameshi.entity.Restaurant;
import com.example.nagoyameshi.repository.CategoryRestaurantRepository;


@Service
public class CategoryRestaurantService {
	private final CategoryRestaurantRepository categoryRestaurantRepository;
	private final CategoryService categoryService;
	
	public CategoryRestaurantService(CategoryRestaurantRepository categoryRestaurantRepository, CategoryService categoryService) {
		this.categoryRestaurantRepository = categoryRestaurantRepository;
		this.categoryService = categoryService;
	}
	
	//指定した店舗のカテゴリのidを、CategoryRestaurantエンティティのidが小さい順に並べ替えられた状態のリスト形式で取得
	public List<Integer> findCategoryIdsByRestaurantOrderByIdAsc(Restaurant restaurant){
		return categoryRestaurantRepository.findCategoryIdsByRestaurantOrderByIdAsc(restaurant);
	}
	
	//フォームから送信されたカテゴリのidリストをもとに、category_restaurantテーブルにデータを登録
	@Transactional
	public void createCategoriesRestaurents(List<Integer> categoryIds, Restaurant restaurant) {
		for(Integer categoryId : categoryIds) { //// 各カテゴリIDを反復処理
			if(categoryId != null) { 
				Optional<Category> optionalCategory = categoryService.findCategoryById(categoryId);
				
				if(optionalCategory.isPresent()) { //// カテゴリが存在するか確認
					Category category = optionalCategory.get();
					
					Optional<CategoryRestaurant> optionalCurrentCategoryRestaurant = categoryRestaurantRepository.findByCategoryAndRestaurant(category, restaurant); //指定した店舗とカテゴリが紐づいたCategoryRestaurantエンティティを取得
					
					//重複するエンティティが存在しない場合は新たにエンティティを作成する
					if(optionalCurrentCategoryRestaurant.isEmpty()) {
						CategoryRestaurant categoryRestaurant = new CategoryRestaurant();  // 新しいインスタンスを作成
						categoryRestaurant.setRestaurant(restaurant);;
						categoryRestaurant.setCategory(category);
						
						categoryRestaurantRepository.save(categoryRestaurant);
					}
				}
			}
		}
	}
	
	//フォームから送信されたカテゴリのidリストをもとに、category_restaurantテーブルのデータを同期する
	@Transactional
	public void syncCategoriesRestaurants(List<Integer> newCategoryIds, Restaurant restaurant) {
		List<CategoryRestaurant> currentCategoriesRestaurants = categoryRestaurantRepository.findByRestaurantOrderByIdAsc(restaurant);
		
		if(newCategoryIds == null) {
			//newCategoryIdsがnullの場合はすべてのエンティティを削除する
			for(CategoryRestaurant currentCategoryRestaurant : currentCategoriesRestaurants) {
				categoryRestaurantRepository.delete(currentCategoryRestaurant);
			}
		}else {
			//既存のエンティティが新しいリストに存在しない場合は削除する
			for(CategoryRestaurant currentCategoryRestaurnt : currentCategoriesRestaurants) {
				if(!newCategoryIds.contains(currentCategoryRestaurnt.getCategory().getId())) {
					categoryRestaurantRepository.delete(currentCategoryRestaurnt);
				}
			}
			
			for(Integer newCategoryId : newCategoryIds) {
				if(newCategoryId != null) {
					Optional<Category> optionalCategory = categoryService.findCategoryById(newCategoryId);
					
					if(optionalCategory.isPresent()) {
						Category category = optionalCategory.get();
						
						Optional<CategoryRestaurant> optionalCurrentCategoryRestaurant = categoryRestaurantRepository.findByCategoryAndRestaurant(category, restaurant);
						
						//重複するエンティティが存在しない場合は新たにエンティティを作成する
						if(optionalCurrentCategoryRestaurant.isEmpty()) {
							CategoryRestaurant categoryRestaurant = new CategoryRestaurant();
							categoryRestaurant.setRestaurant(restaurant);
							categoryRestaurant.setCategory(category);
							
							categoryRestaurantRepository.save(categoryRestaurant);
						}
					}
				}
			}
		}
	}
}
