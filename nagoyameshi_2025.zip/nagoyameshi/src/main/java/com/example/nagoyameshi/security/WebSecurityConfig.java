package com.example.nagoyameshi.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration //設定用のクラスとなる メソッドに@Beanアノテーションをつけるために必要
@EnableWebSecurity //SpringSecurityによるセキュリティ機能を有効にし、認証・認可のルールやログイン・ログアウト処理などの設定が行えるようになる
@EnableMethodSecurity //メソッドレベルでのセキュリティ機能を有効にする
public class WebSecurityConfig {
	@Bean //アプリ起動時にメソッドの戻り値をDIコンテナに登録
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
		http
			.authorizeHttpRequests((requests) -> requests
				.requestMatchers("/css/**", "/images/**", "/js/**", "/storage/**", "/", "/signup/**").permitAll() //すべてのユーザーにアクセスを許可する
				.requestMatchers("/restaurants/{restaurantId}/reviews/**", "/reservations/**", "/restaurants/{restaurantId}/reservations/**", "/favorites/**", "/restaurants/{restaurantId}/favorites/**").hasAnyRole("FREE_MEMBER", "PAID_MEMBER") // 無料会員と有料会員にアクセスを許可するURL
				.requestMatchers("/restaurants/**", "/company", "/terms").hasAnyRole("ANONYMOUS", "FREE_MEMBER", "PAID_MEMBER") //未ログインのユーザー、無料会員、有料会員にアクセスを許可するURL
				.requestMatchers("/subscription/register", "/subscription/create").hasRole("FREE_MEMBER") //無料会員にのみアクセスを許可するURL
				.requestMatchers("/subscription/edit", "/subscription/update", "/subscription/cancel", "/subscription/delete").hasRole("PAID_MEMBER") //有料会員にのみアクセスを許可するURL
				.requestMatchers("/admin/**").hasRole("ADMIN") //管理者のみアクセス可能
				.anyRequest().authenticated() //上記以外のURLはログインが必要（会員・管理者のどちらでもOK）
			)	
			.formLogin((form) -> form
					.loginPage("/login") //ログインページのURL
					.loginProcessingUrl("/login") //ログインフォームの送信先URL
					.defaultSuccessUrl("/?loggedIn") //ログイン成功時のリダイレクト先URL
					.failureUrl("/login?error") //ログイン失敗時のリダイレクト先URLを許可するURL
					.permitAll() //誰でもアクセス可能
				)	
				.logout((logout) -> logout
					.logoutSuccessUrl("/?loggedOut") //ログアウト時のリダイレクト先URL
					.permitAll()
				);
		
        // セキュリティ設定の確定 		
		return http.build(); //HttpSecurityで設定した内容でSecurityFilterChainのインスタンスを構築する
	}
	
	@Bean
	public PasswordEncoder passwordEncoder() { //パスワードのハッシュアルゴリズムを設定
		return new BCryptPasswordEncoder(); //BCryptはパスワード用のハッシュ値を生成してくれる強力なハッシュアルゴリズム
	}
}