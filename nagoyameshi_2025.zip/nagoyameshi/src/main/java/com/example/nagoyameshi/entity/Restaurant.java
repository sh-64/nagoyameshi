package com.example.nagoyameshi.entity;

import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OrderBy;
import jakarta.persistence.Table;
import jakarta.persistence.Transient; //フィールドやメソッドがデータベースとマッピングおよび永続化（保存）の対象外となる
import lombok.Data;
import lombok.ToString;

@Entity
@Table(name = "restaurants")
@Data
@ToString(exclude = {"categoriesRestaurants", "regularHolidaysRestaurants", "reviews", "reservations", "favorites"})
public class Restaurant {
	@Id 
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "image")
	private String image;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "lowest_price")
	private Integer lowestPrice;
	
	@Column(name = "highest_price")
	private Integer highestPrice;
	
	@Column(name = "postal_code")
	private String postalCode;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "opening_time")
	private LocalTime openingTime;
	
	@Column(name = "closingTime")
	private LocalTime closingTime;
	
	@Column(name = "seating_capacity")
	private Integer seatingCapacity;
	
	@Column(name = "created_at", insertable = false, updatable = false) //カラムに挿入または更新する値の管理をデータベースに任せる
	private Timestamp createdAt;
	
	@Column(name = "updated_at", insertable = false, updatable = false)
	private Timestamp updatedAt;
	
	@OneToMany(mappedBy = "restaurant", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE) //mappedBy属性には、外部キーを所有する「多」の側のエンティティにおいてリレーションシップを設定しているフィールド名を指定
	@OrderBy("id ASC") //デフォルトの並び順が昇順になる（idが小さい順）
	private List<CategoryRestaurant> categoriesRestaurants;
	
	@OneToMany(mappedBy = "restaurant", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	@OrderBy("id ASC")
	private List<RegularHolidayRestaurant> regularHolidaysRestaurants;
	
	@OneToMany(mappedBy = "restaurant", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private List<Review> reviews;
	
	@OneToMany(mappedBy = "restaurant", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private List<Reservation> reservations;
	
	@OneToMany(mappedBy = "restaurant", fetch = FetchType.EAGER, cascade = CascadeType.REMOVE)
	private List<Favorite> favorites;
	
	//平均評価を取得する
	@Transient //データベースとは関係なく、エンティティ側で一時的に任意の値を保持できる
	public Double getAverageScore() {
		Double averageScore = reviews.stream() //stream():Reviewエンティティのリストを後述にする
									 .mapToInt(Review::getScore) //scoreフィールドの値を整数のストリームに変換する
									 .average() //整数のストリームに平均値を取得
									 .orElse(0.0); //平均値が存在しない場合、0.0を返す
		return averageScore;
	}
}
