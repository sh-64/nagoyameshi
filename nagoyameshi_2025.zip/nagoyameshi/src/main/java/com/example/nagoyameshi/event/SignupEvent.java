package com.example.nagoyameshi.event;

import org.springframework.context.ApplicationEvent;

import com.example.nagoyameshi.entity.User;

import lombok.Getter;

@Getter //ゲッターのみを自動生成
public class SignupEvent extends ApplicationEvent{ //ApplicationEventを継承
	private User user;
	private String requestUrl;
	
	public SignupEvent(Object source, User user, String requestUrl) {
		super(source); // 親クラス(ApplicationEvent)のコンストラクタを呼び出し、イベント発生元を設定
		
		this.user = user;
		this.requestUrl = requestUrl; //リクエストを受けたURLを保持するため
	}
}