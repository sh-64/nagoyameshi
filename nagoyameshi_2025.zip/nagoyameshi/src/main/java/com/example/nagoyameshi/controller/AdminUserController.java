package com.example.nagoyameshi.controller;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.service.UserService;

@Controller
@RequestMapping("/admin/users") //ルートパスの基準値を設定
public class AdminUserController {
	private final UserService userService;
	
	public AdminUserController(UserService userService) {
		this.userService = userService;
	}
	
	@GetMapping
	public String index(@RequestParam(name = "keyword", required = false) String keyword, //リクエストパラメータの値をその引数にバインドする
						@PageableDefault(page = 0, size = 15, sort = "id", direction = Direction.ASC) Pageable pageable, //ページ情報のデフォルト値を任意に設定
						Model model)
	{
		Page<User> userPage;
		
		if(keyword != null && !keyword.isEmpty()) {
			userPage = userService.findUserByNameLikeOrFuriganaLike(keyword, keyword, pageable); //指定されたキーワードを氏名またはフリガナに含むユーザーをページングされた状態で取得する
		}else {
			userPage = userService.findAllUsers(pageable); //すべてのユーザーをページングされた状態で取得する
		}
		
		model.addAttribute("userPage", userPage); //ページングされた状態のUserエンティティ
		model.addAttribute("keyword", keyword); //送信されたkeywordパラメータ
		
		return "admin/users/index";
	}
	
	@GetMapping("/{id}")
	public String show(@PathVariable(name = "id") Integer id, //URLの一部をその引数にバインドする
						RedirectAttributes redirectAttributes,
						Model model)
	{
		Optional<User> optionalUser = userService.findUserById(id); //指定したidを持つユーザーを取得する
		
		if(optionalUser.isEmpty()) {
			redirectAttributes.addFlashAttribute("errorMessage", "ユーザーが存在しません。");
			
			return "redirect:/admin/users";
		}
		
		User user = optionalUser.get();
		model.addAttribute("user", user);
		
		return "admin/users/show";
	}
}
