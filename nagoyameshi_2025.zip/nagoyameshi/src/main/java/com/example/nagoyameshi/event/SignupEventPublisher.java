package com.example.nagoyameshi.event;

import org.springframework.context.ApplicationEventPublisher; //アプリケーションイベントを発行（配信）するため
import org.springframework.stereotype.Component;

import com.example.nagoyameshi.entity.User;

@Component
public class SignupEventPublisher {
	private final ApplicationEventPublisher applicationEventPublisher;
	
	public SignupEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
		this.applicationEventPublisher = applicationEventPublisher;
	}
	
	public void publishSignupEvent(User user, String requestUrl) {
		applicationEventPublisher.publishEvent(new SignupEvent(this, user,requestUrl)); //イベントを発行　引数には発行したいEventクラスのインスタンスを渡す
	}
}
