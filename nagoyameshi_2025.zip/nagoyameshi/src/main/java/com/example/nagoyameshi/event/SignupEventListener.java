package com.example.nagoyameshi.event;

import java.util.UUID; //重複しないIDを生成するため

import org.springframework.context.event.EventListener; //メソッドをSpringのイベントリスナーとして登録するため
import org.springframework.mail.SimpleMailMessage; //シンプルなテキストメールを作成するため
import org.springframework.mail.javamail.JavaMailSender; //JavaMail APIを使用してメールを送信するため
import org.springframework.stereotype.Component; //クラスをSpringの管理対象コンポーネントとして登録するため。これにより、Springがこのクラスのインスタンスを作成し、依存性を注入することができる

import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.service.VerificationTokenService;

@Component //DIコンテナに登録されるようにする
public class SignupEventListener {
	private final VerificationTokenService verificationTokenService;
	private final JavaMailSender javaMailSender;
	
	//依存性の注入
	public SignupEventListener(VerificationTokenService verificationTokenService, JavaMailSender mailSender) {
		this.verificationTokenService = verificationTokenService;
		this.javaMailSender = mailSender;
	}
	
	@EventListener //イベント発生時に実行する
	private void onSignupEvent(SignupEvent signupEvent) { //引数には通知を受け付けるEventクラスを設定
		User user = signupEvent.getUser(); //Userオブジェクトを取得
		String token = UUID.randomUUID().toString(); //新しいUUIDを生成し、それをtoString()メソッドで文字列に変換
		verificationTokenService.createVerificationToken(user, token); ////トークンをユーザーIDとともにverification_tokensテーブルに保存
		
		String senderAddress = "haruya.soccer.64@gmail.com"; //メールの送信元アドレスを設定
		String recipientAddress = user.getEmail(); //ユーザーのメールアドレスをrecipientAddress変数に設定
		String subject = "メール認証"; //メールの件名をsubject変数に設定
		String confirmationUrl = signupEvent.getRequestUrl() + "/verify?token=" + token; //メール認証のためのURLを生成 signupEvent.getRequestUrl()でイベントからリクエストURLを取得し、/verify?token=に生成されたトークンを連結
		String message = "以下のリンクをクリックして会員登録を完了してください。"; //メール本文のメッセージをmessage変数に設定
		
		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom(senderAddress);
		mailMessage.setTo(recipientAddress);
		mailMessage.setSubject(subject);
		mailMessage.setText(message + "\n" + confirmationUrl);
		javaMailSender.send(mailMessage);
	}
}
