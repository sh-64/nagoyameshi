package com.example.nagoyameshi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.entity.VerificationToken;
import com.example.nagoyameshi.event.SignupEventPublisher;
import com.example.nagoyameshi.form.SignupForm;
import com.example.nagoyameshi.service.UserService;
import com.example.nagoyameshi.service.VerificationTokenService;

import jakarta.servlet.http.HttpServletRequest;


@Controller //コントローラとして機能
public class AuthController {
	private final UserService userService;
	private final SignupEventPublisher signupEventPublisher;
	private final VerificationTokenService verificationTokenService;
	
	public AuthController(UserService userService, SignupEventPublisher signupEventPublisher, VerificationTokenService verificationTokenService) {
		this.userService = userService;
		this.signupEventPublisher = signupEventPublisher;
		this.verificationTokenService = verificationTokenService;
	}
	
	@GetMapping("/login") //Getメソッドをそのメソッドにマッピング
	public String login() {
		return "auth/login";
	}
	
	@GetMapping("/signup")
	public String signup(Model model) {
		model.addAttribute("signupForm", new SignupForm());
		return "auth/signup";
	}
	
	@PostMapping("/signup")
	public String signup(@ModelAttribute @Validated SignupForm signupForm, //@ModelAttribute:フォームから送信されたデータをその引数にバインド
						 BindingResult bindingResult, //バリエーションのエラー内容を格納
						 RedirectAttributes redirectAttributes, //リダイレクト先にデータを渡すため
						 HttpServletRequest httpServletRequest, //HTTPリクエストに関する情報を取得
						 Model model) 
	{
		//メールアドレスが登録済みであれば、BindingResultオブジェクトにエラー内容を追加する
		if(userService.isEmailRegistered(signupForm.getEmail())) {
			FieldError fieldError = new FieldError(bindingResult.getObjectName(), "email", "すでに登録済みのメールアドレスです。"	);
			bindingResult.addError(fieldError);
		}
		
		 // パスワードとパスワード（確認用）の入力値が一致しなければ、BindingResultオブジェクトにエラー内容を追加する
        if (!userService.isSamePassword(signupForm.getPassword(), signupForm.getPasswordConfirmation())) {
            FieldError fieldError = new FieldError(bindingResult.getObjectName(), "password", "パスワードが一致しません。"); 
            //引数として受け取ったBindingResultオブジェクトには、addError()メソッドで独自のエラー内容を追加できる
            //addError()メソッドにはFieldErrorクラスのインスタンスを渡す
            //FieldErrorクラスのコンストラクタに渡す引数
            //第1引数：エラー内容を格納するオブジェクト名
            //第2引数：エラーを発生させるフィールド名
            //第3引数：エラーメッセージ
            bindingResult.addError(fieldError);
        }
		
        if (bindingResult.hasErrors()) { //エラーが存在するかどうかをチェック
            model.addAttribute("signupForm", signupForm); //addAttribute("ビュー側から参照する変数名", ビューに渡すデータ)

            return "auth/signup";
        }
        
        User createdUser = userService.createUser(signupForm); //signupFormの内容を基に新しいユーザーを作成
        String requestUrl = new String(httpServletRequest.getRequestURL()); //httpServletRequestからリクエストURLを取得し、String型のrequestUrl変数に格納
        signupEventPublisher.publishSignupEvent(createdUser, requestUrl); //イベントを発行
        redirectAttributes.addFlashAttribute("successMessage", "ご入力いただいたメールアドレスに認証メールを送信しました。メールに記載されているリンクをクリックし、会員登録を完了してください。"); //addFlashAttribute("リダイレクト先から参照する変数名", リダイレクト先に渡すデータ) 成功メッセージをFlash属性として追加。Flash属性は、リダイレクト後のページで一度だけ利用できる属性
        
        return "redirect:/"; //return "redirect:ルートパス";
	}   
	
	@GetMapping("/signup/verify")
    public String verify(@RequestParam(name = "token") String token, Model model) { //@RequestParam:リクエストパラメータの値をバインドする
        VerificationToken verificationToken = verificationTokenService.findVerificationTokenByToken(token); //指定されたトークン(token)に対応するVerificationTokenオブジェクトを取得
        
        if (verificationToken != null) { //verificationTokenがnullでない場合
            User user = verificationToken.getUser();  //ユーザー情報を取得
            userService.enableUser(user); //取得したユーザー(user)のアカウントを有効化
            String successMessage = "会員登録が完了しました。";
            model.addAttribute("successMessage", successMessage);            
        } else {
            String errorMessage = "トークンが無効です。";
            model.addAttribute("errorMessage", errorMessage);
        }
        
        return "auth/verify";         
    }
}	