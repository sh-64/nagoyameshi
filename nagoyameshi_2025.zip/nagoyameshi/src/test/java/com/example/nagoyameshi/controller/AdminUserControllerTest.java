package com.example.nagoyameshi.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*; //HTTPリクエストを作成するためのメソッドを提供するクラス
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*; //リクエストの結果に対する期待を定義するためのメソッド

import org.junit.jupiter.api.Test; //JUnitのテストアノテーションを使うためのクラス
import org.springframework.beans.factory.annotation.Autowired; // Springの依存性注入機能を利用するためのクラス
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc; //MockMvcの自動設定を行うためのアノテーション
import org.springframework.boot.test.context.SpringBootTest; //Spring Bootアプリケーション全体のテストを行うアノテーション
import org.springframework.security.test.context.support.WithUserDetails; //指定したユーザーの情報でテスト環境をセットアップ
import org.springframework.test.context.ActiveProfiles; //テスト時に特定のプロファイルをアクティブにするためのアノテーション
import org.springframework.test.web.servlet.MockMvc; //モックMVCリクエストを作成し、HTTPリクエストをテストするためのクラス

@SpringBootTest //テスト時にアプリのコンテキストを起動
@AutoConfigureMockMvc //MockMvcインスタンスを注入できるようになる
@ActiveProfiles("test") //テスト時に異なる設定ファイルを適用する
public class AdminUserControllerTest {
	@Autowired //依存性の注入(フィールドインジェクション)
	private MockMvc mockMvc;
	
	@Test //メソッドがテストメソッドとして認識され、テスト時に実行される
	public void 未ログインの場合は管理者用の会員一覧ページからログインページにリダイレクトする() throws Exception{
		mockMvc.perform(get("/admin/users")) //GETリクエストを送信
			   .andExpect(status().is3xxRedirection()) // 3xxリダイレクトステータスを期待
			   .andExpect(redirectedUrl("http://localhost/login")); // ログインページにリダイレクト
	}
	
	@Test
	@WithUserDetails("taro.samurai@example.com") //そのユーザーとしてログインする
	public void 一般ユーザーとしてログイン済みの場合は管理者用の会員一覧ページが表示されずに403エラーが発生する() throws Exception{
		mockMvc.perform(get("/admin/users")) // perform()メソッドを使うことで、HTTPリクエストを送信する振る舞いを実現
		       .andExpect(status().isForbidden()); //andExpect()メソッドを使うことで、HTTPレスポンスが期待する内容かどうかを検証
	}
	
	@Test
	@WithUserDetails("hanako.samurai@example.com")
	public void 管理者としてログイン済みの場合は管理者用の会員一覧ページが正しく表示される() throws Exception{
		mockMvc.perform(get("/admin/users"))
		       .andExpect(status().isOk())
		       .andExpect(view().name("admin/users/index"));
	}
	
	@Test
	public void 未ログインの場合は管理者用の会員詳細ページからログインページにリダイレクトする() throws Exception{
		mockMvc.perform(get("/admin/users/1"))
		       .andExpect(status().is3xxRedirection())
		       .andExpect(redirectedUrl("http://localhost/login"));
	}
	
	@Test
	@WithUserDetails("taro.samurai@example.com")
	public void 一般ユーザーとしてログイン済みの場合は管理者用の会員詳細ページが表示されずに403エラーが発生する() throws Exception{
		mockMvc.perform(get("/admin/users/1"))
		       .andExpect(status().isForbidden());
	}
	
	@Test
	@WithUserDetails("hanako.samurai@example.com")
	public void 管理者としてログイン済みの場合は管理者用の会員詳細ページが正しく表示される() throws Exception{
		mockMvc.perform(get("/admin/users/1"))
		       .andExpect(status().isOk())
		       .andExpect(view().name("admin/users/show"));
	}
}
